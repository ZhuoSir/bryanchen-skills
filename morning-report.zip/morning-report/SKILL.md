---
name: morning-report
description: "生成每日晨报：国内主要城市天气预报（北京/深圳/上海/杭州/通辽/崇礼）、当日国际/国内综合新闻（5-10条）、AI 行业动态（量子位/TechCrunch/InfoQ RSS）、虎扑足球与篮球新闻。触发词：晨报、早报、今日新闻简报、morning report、daily briefing。NOT for: 深度专题调研、历史新闻检索、实时比分查询。"
---

# 晨报 Skill（morning-report）

零依赖（Python 3 标准库 + 免费新闻 API/RSS），不使用任何 API Key，**不通过搜索引擎抓新闻**。

## When to Use

✅ 用户说：晨报 / 早报 / 今日新闻 / 每日简报 / morning report / "给我一份今天的晨报"

❌ 不适用：历史日期的新闻回顾、单一事件的深度调研、实时赛事比分

## 执行流程

所有脚本位于本 skill 目录的 `scripts/` 下，用 bash 运行。**第 1、2、3、4 步互相独立，应在同一个消息里并行发起。**

### 第 1 步：国内主要城市天气

```bash
python3 scripts/weather.py
```

- 主源 Open-Meteo（一次请求返回全部城市，~1s），兜底 wttr.in（仅当前天气，无当日高低温）
- 城市固定为：北京、深圳、上海、杭州、通辽、崇礼（改城市改脚本顶部 `CITIES`）
- 输出每城 `now`（当前温度/体感/湿度/风速）与 `today`（高低温/天气/降水概率），已带 emoji

### 第 2 步：综合新闻（国际 + 国内）

```bash
python3 scripts/news_api.py --max 15
```

- 免费新闻 API，免 Key。脚本内置降级链（按实测速度排序，**经常超时的放最后**）：
  1. `60s API` 镜像 ×2（每天60秒读懂世界 JSON，~1-2s）
  2. `yyxw.com` 每日早报页（HTML，~0.5s）
  3. `Google News 中文 RSS`（国内网络经常超时，仅作最后兜底）
- 输出 `items` 为国际/国内混合条目，**由你按内容归类到"国际新闻"和"国内新闻"两个板块**
- 条目链接为百度搜索链接（源本身无独立文章链接）；digest 原文在顶层 `source_link`，可在晨报末尾注明
- 从中选 **5–10 条，保底 5 条**（国际/国内尽量兼顾）；注意 `warning` 字段（数据日期非今天时需在晨报中注明）

### 第 3 步：AI 行业新闻

```bash
python3 scripts/fetch_rss.py --days 2 --per-source 3
```

- 源：量子位、TechCrunch AI、InfoQ 中文（RSS，按发布时间过滤最近 N 天）
- 从合并结果中选 **约 5 条**，中英文源都要兼顾；某源 `ok: false` 时降低该源配额即可，不必重试超过 1 次

### 第 4 步：体育新闻 + 当日赛程（虎扑）

```bash
python3 scripts/hupu.py --per-section 5
```

- 新闻源：虎扑移动端频道页 `m.hupu.com/nba`（篮球）、`m.hupu.com/soccer`（足球），静态 HTML 免 Key
- 赛程源：`m.hupu.com/nba/schedule`、`m.hupu.com/soccer/schedule`（页面内嵌 JSON，按当天日期过滤）
- 输出 `sections.basketball` / `sections.football`（新闻）：**置顶帖全量保留在前并标注 `"pinned": true`，普通帖取前 5–10 条**（`--per-section` 控制）
- 输出 `matches.basketball` / `matches.football`（当日比赛）：每条含时间、赛事、主客队、比分、状态（未开始/已结束）；**空列表表示今日无比赛，晨报中如实写"今日无 NBA 比赛"等，不要省略**
- 新闻页**不含发布时间**，按最新活跃排序；在晨报体育板块注明"虎扑实时热帖"，置顶条目用 📌 标出

### 第 5 步：组装输出

阅读各脚本 JSON，为每条新闻写**一句话中文摘要**（英文标题需翻译），按模板输出：

```markdown
# ☀️ 晨报 · <YYYY-MM-DD 周X>

## 🌤️ 今日天气
- **北京** ⛅ 25~32°C（当前 30°C，体感 35°C，湿度 60%）
- ……逐城一行，格式：<emoji> 最低~最高°C（当前 xx°C，降水概率 xx%）；有雨/雷暴时加 ☔ 提醒带伞

## 🌍 国际新闻
1. **标题** — 一句话摘要 [来源](url)

## 🇨🇳 国内新闻
（同上）

## 🤖 AI 动态
（同上，标注来源媒体名）

## ⚽ 足球
**今日赛程**（来自 matches.football，无比赛则写"今日无焦点赛事"）
- 19:35 中超第24轮 上海海港 vs 青岛海牛（未开始）/ 国际米兰 4-1 蒙扎（已结束）
**热帖**（虎扑实时热帖，置顶用 📌）
1. **标题** — 一句话摘要 [来源](url)

## 🏀 篮球
**今日赛程**（同上；NBA 休赛期为"今日无 NBA 比赛"）
**热帖**
1. **标题** — 一句话摘要 [来源](url)

---
> 💌 **今日寄语**：<一句温暖的激励话语；若 news_api.py 输出了 tip 字段（60s API 每日一句）优先采用，否则自己写一句原创的>
>
> —— 爱你的悠悠
```

### 第 6 步（可选）：邮件投递

用户要求"把晨报发到邮箱"时，用 `email-skill` 发送。**必须用 Markdown 文件方式投递**，
链接才会渲染成超链接（纯文本会把长 URL 裸露刷屏）：

```bash
# 1. 把上面模板的晨报原样写入临时 md 文件（[来源](url) 格式保持不动）
# 2. 发送
python3 <email-skill>/scripts/send_mail.py --to <收件人> \
  --subject "☀️ 晨报 · <YYYY-MM-DD 周X>" --markdown-file /tmp/morning_report.md
```

- 发送为 multipart/alternative：HTML 版（链接可点、有排版）+ 纯文本兜底
- 发送后清理临时 md 文件；发送前向用户确认收件人

## 降级策略

1. `news_api.py` 内置降级链（60s API ×2 → yyxw → Google News RSS），全部失败时在对应板块注明"今日综合新闻暂无法获取"
2. `weather.py` 双源全失败 → 晨报省略天气板块并注明；`fetch_rss.py` / `hupu.py` 个别源失败 → 用其余源补齐，不阻塞整体
3. 脚本整体异常（如网络不通）→ 直接告知用户哪一步失败及报错，**不要编造新闻**
4. 若运行环境中恰好有 `web_search`/`advanced_search` 工具，允许作为最终兜底手段，并在晨报末尾注明

## 铁律

- 所有条目必须来自脚本实际输出，**禁止凭模型记忆编造新闻或链接**
- 每条必须附可点击的来源链接
- 条目数量不达标时优先换查询词/放宽时间重搜，而不是编造凑数

## 验证

完成后自检：① 国际国内合计 ≥5 条 ② 五个板块齐全（天气在最上） ③ 每条有链接 ④ 日期正确
